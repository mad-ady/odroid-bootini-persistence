# odroid-bootini-persistence
Persistence script for boot.ini (keep user's settings)
